AP Psychology study series — LaTeX sources
Build:  latexmk -xelatex <file>.tex      (XeLaTeX required; fonts: TeX Gyre Pagella, Inter)
All files share ap-psych.sty.

Question syntax:
  \begin{q}{<correct position 1-4>}{<rule tag>}{<why>}
    Stem text.
    \ch{choice 1}{choice 2}{choice 3}{choice 4}     % one per line
    \chh{...}{...}{...}{...}                        % short choices, 2 columns
  \end{q}
Letters, the answers-only strip, the #/Ans./Why/Rule table and the question total
(\qtotal, used in the scoring line) are generated automatically, so questions can be
reordered or added without editing the key. Run latexmk twice-safe: it reruns for \qtotal.
