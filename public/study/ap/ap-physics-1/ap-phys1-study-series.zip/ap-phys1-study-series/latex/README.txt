AP Physics 1: Algebra-Based study series: LaTeX sources
Build: tectonic <file>.tex   or   latexmk -xelatex <file>.tex
Fonts are loaded by file name from the TeX tree (TeX Gyre Pagella, Inter, DejaVu Sans Mono), so no system fonts
are needed. All files share ap-sci.sty; graphs are pgfplots.

Each unit has a Study Guide (notes, worked examples and section checks) and a Question Set (multiple choice and one
free-response question with a scoring guide). Question syntax:
  \begin{q}{<correct position 1-4>}{<topic tag>}{<why>}
    Stem text.
    \ch{choice 1}{choice 2}{choice 3}{choice 4}     % one per line
    \chh{...}{...}{...}{...}                        % short choices, 2 columns
  \end{q}
Letters, the answers-only strip, the #/Ans./Why/Rule table and \qtotal are generated.
These .tex files are generated from the Python content model in the site repository (quizzes/ap_physics_1/),
which also drives the interactive quizzes on universitybikeshop.com/study.
