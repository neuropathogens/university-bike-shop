AP Physics C study series (Mechanics Units 1-7, E&M Units 8-13), Paul Wang, November 2026.

Each unit has a Study Guide (notes + section checks) and a Question Set (multiple choice + one free-response
question with a scoring guide). Compile any file with XeLaTeX:  latexmk -xelatex <file>.tex
(needs ap-physc.sty beside it, TeX Gyre Pagella and Inter fonts).

The .tex files are generated from a Python content model (one module per unit) that also builds the
interactive quizzes on universitybikeshop.com/study. A question is
  \begin{q}{<correct position 1-4>}{<topic tag>}{<why>} stem \ch{A}{B}{C}{D} \end{q}
and the letters, answer key and question total are generated from it.
