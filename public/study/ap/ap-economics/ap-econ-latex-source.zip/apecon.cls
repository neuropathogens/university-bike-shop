% apecon.cls -- AP Economics study guides, laid out as an academic preprint
% Paul Wang LLC, 2026. Shared by every unit guide (micro/*.tex, macro/*.tex).
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{apecon}[2026/11/18 AP Economics unit guide (preprint style)]
\LoadClass[11pt,letterpaper]{article}

% ---------------------------------------------------------------- packages
\RequirePackage[T1]{fontenc}
\RequirePackage[utf8]{inputenc}
\RequirePackage{lmodern}
\RequirePackage[protrusion=true,expansion=true]{microtype}
\RequirePackage[margin=1.1in,headheight=14pt]{geometry}
\RequirePackage{amsmath,amssymb}
\RequirePackage{booktabs,tabularx,array,multirow}
\RequirePackage{enumitem}
\RequirePackage{caption}
\RequirePackage{subcaption}
\RequirePackage{titlesec}
\RequirePackage{xcolor}
\RequirePackage{fancyhdr}
\RequirePackage{float}
\RequirePackage{econgraphs}
\RequirePackage[hidelinks]{hyperref}

% ---------------------------------------------------------------- metadata
\newcommand\course[1]{\gdef\@course{#1}}      % e.g. AP Microeconomics
\newcommand\unit[1]{\gdef\@unit{#1}}          % e.g. 2
\newcommand\unitname[1]{\gdef\@unitname{#1}}  % e.g. Supply and Demand
\newcommand\status[1]{\gdef\@status{#1}}
\newcommand\keywords[1]{\gdef\@keywords{#1}}
\newcommand\weighting[1]{\gdef\@weighting{#1}}
\course{AP Economics}\unit{0}\unitname{}\status{Published draft}
\keywords{}\weighting{}
\date{November 18, 2026}

% ---------------------------------------------------------------- title block
\renewcommand\maketitle{%
  \thispagestyle{plain}%
  \begin{center}
    {\small\scshape \@course\ \textperiodcentered\ Unit \@unit\par}\vspace{0.7em}
    {\LARGE\bfseries \@title\par}\vspace{1.1em}
    {\large Paul Wang\textsuperscript{1}\par}\vspace{0.25em}
    {\small \textsuperscript{1}Paul Wang LLC\par}\vspace{0.7em}
    {\small \@date\ \textperiodcentered\ \@status\par}\vspace{0.35em}
    {\small \hyperref[sec:quickref]{Jump to the quick-reference sheet $\downarrow$}\par}
  \end{center}\vspace{0.4em}}

\renewenvironment{abstract}{%
  \begin{center}\small\bfseries Abstract\end{center}\vspace{-0.6em}
  \begin{quote}\small}{%
  \par\smallskip\noindent\textbf{Keywords:} \@keywords
  \end{quote}\vspace{0.6em}}

% ---------------------------------------------------------------- headings
\titleformat{\section}{\large\bfseries}{\thesection}{0.8em}{}
\titleformat{\subsection}{\normalsize\bfseries}{\thesubsection}{0.7em}{}
\titleformat{\subsubsection}[runin]{\normalsize\bfseries\itshape}{}{0em}{}[.]
\titlespacing*{\section}{0pt}{2.0ex plus .6ex minus .2ex}{1.0ex plus .2ex}
\titlespacing*{\subsection}{0pt}{1.6ex plus .5ex minus .2ex}{0.7ex plus .2ex}

% A CED topic is a section whose number is the College Board topic number.
\newcommand\topic[2]{%
  \renewcommand\thesection{#1}%
  \setcounter{subsection}{0}%
  \section{#2}\label{topic:#1}}
% Unnumbered sections that can still be linked to.
\newcommand\usection[2][]{\section*{#2}\phantomsection
  \if\relax\detokenize{#1}\relax\else\label{#1}\fi}

% ---------------------------------------------------------------- body helpers
\newcommand\term[1]{\emph{#1}}
\newcommand\Problem{\par\medskip\noindent\textbf{Problem.}\enskip}
\newcommand\Approach{\par\smallskip\noindent\textbf{Approach.}\enskip}
\newcommand\Takeaway{\par\smallskip\noindent\textbf{Takeaway.}\enskip}
\newcommand\Exam{\par\smallskip\noindent\textbf{On the exam.}\enskip}
\newcommand\up{$\uparrow$}
\newcommand\dn{$\downarrow$}
\newcommand\then{$\;\Rightarrow\;$}

% Display equation with a label on the left, used for key formulas.
\newcommand\formula[2]{\par\smallskip\noindent\hspace*{2em}%
  \makebox[14em][l]{\textit{#1}}$\displaystyle #2$\par\smallskip}

\setlist{itemsep=2pt,topsep=4pt,parsep=0pt}
\setlist[itemize]{leftmargin=1.4em,label=\textbullet}
\setlist[enumerate]{leftmargin=1.6em}

% ---------------------------------------------------------------- floats
\captionsetup{font={small,it},labelfont={small,it},labelsep=period,
  justification=justified,singlelinecheck=true}
\captionsetup[table]{position=top,skip=4pt}
\captionsetup[figure]{skip=6pt}
\captionsetup[sub]{font={small,it},labelformat=parens,labelsep=space}
\renewcommand\arraystretch{1.15}
\setlength{\tabcolsep}{5pt}
\newcolumntype{L}{>{\raggedright\arraybackslash}X}
\setlength{\floatsep}{12pt plus 2pt}
\setlength{\textfloatsep}{14pt plus 2pt}
\setlength{\intextsep}{12pt plus 2pt}
\renewcommand\topfraction{0.85}
\renewcommand\textfraction{0.1}
\renewcommand\floatpagefraction{0.75}

% ---------------------------------------------------------------- page style
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small\scshape \@course\ \textperiodcentered\ Unit \@unit}
\fancyhead[R]{\small\itshape \@unitname}
\fancyfoot[L]{\footnotesize Paul Wang \textperiodcentered\ \@status}
\fancyfoot[R]{\footnotesize \thepage}
\renewcommand\headrulewidth{0.4pt}
\fancypagestyle{plain}{\fancyhf{}\renewcommand\headrulewidth{0pt}%
  \fancyfoot[C]{\footnotesize\thepage}}

\setlength{\parindent}{1.2em}
\setlength{\parskip}{0pt}
\frenchspacing
\renewcommand\refname{References}
