# AP Economics unit guides (LaTeX)

12 guides, one per unit: `micro/micro-u1.tex` ... `micro/micro-u6.tex`, `macro/macro-u1.tex` ... `macro/macro-u6.tex`.
Every College Board CED topic is its own section, numbered with the topic number (`\topic{2.3}{Price Elasticity of Demand}`).

- `apecon.cls` - preprint layout (title block, abstract + keywords, italic captions, run-in Problem./Approach. labels, header/footer)
- `econgraphs.sty` - B/W TikZ helpers (`\axes`, `\eqpt`, `\xguide`, `\yguide`, `\panel`, `\ppc`, and the shared MC/ATC/AVC cost curves)
- `./build.sh [file.tex ...]` - compiles everything (or the files given) into `build/`

## Practice sets
- `appractice.cls` - practice-set layout (title block, abstract, scoring line, rule boxes, answer blanks, key strip + #/Ans./Why/Rule table)
- `practice/data/*.py` - question data. `Q(stem, correct, [4 wrong], why)` lets the generator place the answer; `F(stem, [5 choices], 'C', why)` fixes the order (numeric choices)
- `python3 practice/gen.py` - writes `practice/*.tex`, spreading answers evenly over A-E with no three in a row; then `./build.sh practice/*.tex`
