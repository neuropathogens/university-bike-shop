% appractice.cls -- AP Economics practice sets (practice-set format)
% Builds on apecon.cls so guides and practice sets share one look.
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{appractice}[2026/11/18 AP Economics practice set]
\LoadClass{apecon}
\RequirePackage{longtable}
\RequirePackage{tcolorbox}
\RequirePackage{needspace}

\newcommand\numq[1]{\gdef\@numq{#1}}
\newcommand\pace[1]{\gdef\@pace{#1}}
\numq{0}\pace{}

% ---------------------------------------------------------------- title block
\renewcommand\maketitle{%
  \thispagestyle{plain}%
  \begin{center}
    {\small\scshape \@course\ \textperiodcentered\ Unit \@unit\ \textperiodcentered\ Practice Set\par}\vspace{0.7em}
    {\LARGE\bfseries \@title\par}\vspace{1.1em}
    {\large Paul Wang\textsuperscript{1}\par}\vspace{0.25em}
    {\small \textsuperscript{1}Paul Wang LLC\par}\vspace{0.7em}
    {\small \@date\ \textperiodcentered\ \@status\par}\vspace{0.35em}
    {\small \hyperref[sec:key]{Answer key on the last page $\downarrow$}\par}
  \end{center}\vspace{0.2em}}

\newcommand\scoreline{%
  \begin{center}\small
  \textbf{Score:}\ \rule{2.6em}{0.4pt}\,/\,\@numq
  \qquad\textperiodcentered\qquad
  \textbf{Time:}\ \rule{2.6em}{0.4pt}\ min
  \qquad\textperiodcentered\qquad
  \textbf{Exam pace:}\ \@pace
  \end{center}\vspace{0.3em}}

% ---------------------------------------------------------------- rule box
\newtcolorbox{rulebox}{colback=white,colframe=black,boxrule=0.5pt,arc=0pt,
  left=6pt,right=6pt,top=4pt,bottom=4pt,fontupper=\small,before skip=4pt,after skip=8pt}

% ---------------------------------------------------------------- questions
% \qitem{number}{stem}{A}{B}{C}{D}{E}
\newcommand\ansblank{\rule[-0.15em]{2.0em}{0.4pt}}
\newcommand\qitem[7]{%
  \par\addvspace{7pt}\noindent
  \begin{minipage}{\linewidth}\setlength{\parindent}{0pt}%
  \makebox[4.2em][l]{\ansblank\hspace{0.4em}\textbf{#1.}}%
  \begin{minipage}[t]{\dimexpr\linewidth-4.2em\relax}\setlength{\parindent}{0pt}%
  #2\par\vspace{2pt}
  \begin{enumerate}[label=(\Alph*),leftmargin=2.2em,labelsep=0.5em,itemsep=0pt,topsep=1pt]
  \item #3 \item #4 \item #5 \item #6 \item #7
  \end{enumerate}
  \end{minipage}
  \end{minipage}\par}

% ---------------------------------------------------------------- key
\newcommand\keysection{\clearpage\usection[sec:key]{Answer key}}
