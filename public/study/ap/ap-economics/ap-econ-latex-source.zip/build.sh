#!/bin/bash
# usage: ./build.sh [file.tex ...]   (default: all guides)
cd "$(dirname "$0")"
export TEXINPUTS="$(pwd)//:"
files=("$@"); [ ${#files[@]} -eq 0 ] && files=(micro/*.tex macro/*.tex)
for f in "${files[@]}"; do
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build/tmp -quiet "$f" >/dev/null 2>&1 \
    && cp build/tmp/$(basename "${f%.tex}").pdf build/ && echo "ok  $f" \
    || { echo "ERR $f"; grep -A4 '^!' build/tmp/$(basename "${f%.tex}").log | head -20; }
done
