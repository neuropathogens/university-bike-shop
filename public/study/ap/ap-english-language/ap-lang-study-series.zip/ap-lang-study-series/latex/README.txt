AP English Language study series — LaTeX sources
Build:  latexmk -xelatex <file>.tex      (XeLaTeX required; fonts: TeX Gyre Pagella, Inter)
All files share ap-lang.sty (the AP Psychology series style plus passage environments).

Question syntax:
  \begin{q}{<correct position 1-4>}{<rule tag>}{<why>}
    Stem text.
    \ch{choice 1}{choice 2}{choice 3}{choice 4}     % one per line
    \chh{...}{...}{...}{...}                        % short choices, 2 columns
  \end{q}
Passages:
  \begin{passage}{Passage 1}{Introductory note in italics.}
    \pn{1} Paragraph one ...        \sn{1} numbered sentences in writing drafts
  \end{passage}
  \begin{source}{Source A}{Citation line.} ... \end{source}   % synthesis sources
Rule tags name the guide section (2.4 = Part 2, Section 4). Letters, the answers-only
strip, the #/Ans./Why/Rule table and the question total (\qtotal) are generated
automatically. All passages, writers, places, and figures are fictional.
