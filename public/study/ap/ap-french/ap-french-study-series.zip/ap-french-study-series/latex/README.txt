AP French Language and Culture study series: LaTeX sources
Build: tectonic <file>.tex   or   latexmk -xelatex <file>.tex
Fonts are loaded by file name from the TeX tree (TeX Gyre Pagella, Inter, DejaVu Sans Mono; Harano Aji for Japanese),
so no system fonts are needed. All files share ap-wl.sty.

Question syntax:
  \begin{q}{<correct position 1-4>}{<rule tag>}{<why>}
    Stem text.
    \ch{choice 1}{choice 2}{choice 3}{choice 4}     % one per line
    \chh{...}{...}{...}{...}                        % short choices, 2 columns
  \end{q}
Letters, the answers-only strip, the #/Ans./Why/Rule table and \qtotal are generated.
These .tex files are generated from the Python content model in the site repository
(quizzes/ap_french/content/), which also drives the interactive quizzes.
