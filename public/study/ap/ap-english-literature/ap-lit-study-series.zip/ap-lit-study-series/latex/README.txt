AP English Literature study series -- LaTeX sources
Build:  latexmk -xelatex <file>.tex      (XeLaTeX required; fonts: TeX Gyre Pagella, Inter)
All files share ap-lit.sty.

Question syntax (as in the AP Psychology series):
  \begin{q}{<correct position 1-4>}{<rule tag>}{<why>}
    Stem text.
    \ch{choice 1}{choice 2}{choice 3}{choice 4}     % one per line
    \chh{...}{...}{...}{...}                        % short choices, 2 columns
  \end{q}
Letters, the answers-only strip, the #/Ans./Why/Rule table and the question total
(\qtotal) are generated automatically.

Texts:
  \begin{passage}{Heading}{Intro} \pp paragraph \pp paragraph ... \end{passage}   numbered paragraphs
  \begin{poem}{Heading}{Intro} \pl{line} \pli{indented line} \stanza ... \end{poem}  line numbers every 5
  Drama inside poem: \spk{SPEAKER} and \sd{stage direction} (unnumbered).
Questions cite "paragraph 3" or "line 9"; the web quizzes highlight the cited
paragraph or line from that wording.

All literary passages are in the public domain (published before 1929) and were
checked against Project Gutenberg texts.
