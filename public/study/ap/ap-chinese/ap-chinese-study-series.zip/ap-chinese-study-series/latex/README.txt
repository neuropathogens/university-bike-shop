AP Chinese Language and Culture study series: LaTeX sources
Build: latexmk -xelatex <file>.tex   (XeLaTeX; fonts: TeX Gyre Pagella, Inter, Noto Serif/Sans CJK SC)
All files share ap-chinese.sty, the AP Psychology series style plus automatic switching to Noto CJK
for Chinese text (one XeTeX inter-character class; xeCJK is not needed).

Question syntax (same as the AP Psychology series):
  \begin{q}{<correct position 1-4>}{<rule tag>}{<why>}
    Stem text.
    \ch{choice 1}{choice 2}{choice 3}{choice 4}     % one per line
    \chh{...}{...}{...}{...}                        % short choices, 2 columns
  \end{q}
Letters, the answers-only strip, the #/Ans./Why/Rule table and \qtotal are generated.
These .tex files are generated from the Python content model in the site repository
(quizzes/ap_chinese/content/), which also drives the interactive quizzes.
