\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{satvocab}[2026/11/17 SAT Vocabulary study-guide series]
\LoadClass[11pt,letterpaper]{article}

\RequirePackage[T1]{fontenc}
\RequirePackage[utf8]{inputenc}
\RequirePackage{lmodern}
\RequirePackage{textcomp}
\RequirePackage{amsmath,amssymb}
\RequirePackage[margin=1in,headheight=14pt]{geometry}
\RequirePackage{microtype}
\RequirePackage{booktabs,longtable,tabularx,array}
\RequirePackage{multicol}
\RequirePackage[shortlabels]{enumitem}
\RequirePackage{caption}
\RequirePackage{fancyhdr}
\RequirePackage{titlesec}
\RequirePackage{needspace}
\RequirePackage[hidelinks,pdfusetitle]{hyperref}

\captionsetup{font=small,labelfont=bf,skip=4pt}
\setlength{\parindent}{0pt}
\setlength{\parskip}{4pt}
\setlength{\columnsep}{22pt}

% ---- metadata -------------------------------------------------------
\newcommand{\series}{SAT Vocabulary Series}
\newcommand{\partlabel}[1]{\def\@partlabel{#1}}
\newcommand{\course}[1]{\def\@course{#1}}
\newcommand{\keywords}[1]{\def\@keywords{#1}}
\newcommand{\scoring}[1]{\def\@scoring{#1}}
\partlabel{}\course{}\keywords{}\scoring{}

% ---- title block (paper style) -------------------------------------
\renewcommand{\maketitle}{%
  \thispagestyle{plain}%
  \begin{center}
    {\small\scshape \series\ \textperiodcentered\ \@partlabel\par}\vspace{10pt}
    {\LARGE\bfseries \@title\par}\vspace{12pt}
    {\large \@author\par}\vspace{3pt}
    {\small \@course\par}\vspace{3pt}
    {\small \@date\par}
  \end{center}\vspace{6pt}}

\renewenvironment{abstract}{%
  \begin{center}\small\bfseries Abstract\end{center}\vspace{-4pt}%
  \begin{quote}\small}{%
  \ifx\@keywords\@empty\else\par\vspace{4pt}\textbf{Keywords:} \@keywords\fi
  \ifx\@scoring\@empty\else\par\vspace{4pt}\textbf{Scoring:} \@scoring\fi
  \end{quote}\vspace{4pt}}

% ---- headings & page style ------------------------------------------
\titleformat{\section}{\large\bfseries}{\thesection}{0.8em}{}
\titleformat{\subsection}{\normalsize\bfseries}{\thesubsection}{0.7em}{}
\titlespacing*{\section}{0pt}{14pt}{6pt}
\titlespacing*{\subsection}{0pt}{10pt}{4pt}

\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small\scshape \series}
\fancyhead[R]{\small\scshape \@partlabel}
\fancyfoot[C]{\small\thepage}
\renewcommand{\headrulewidth}{0.4pt}

% ---- questions ------------------------------------------------------
% \begin{question}{number}{tag} passage \stem{...} \choices{A}{B}{C}{D} \end{question}
\newcommand{\blank}{\underline{\hspace{4.5em}}}
\newcommand{\ansblank}{\rule[-1pt]{2.2em}{0.4pt}}
\newenvironment{question}[2]{%
  \needspace{7\baselineskip}%
  \par\vspace{6pt}\noindent
  \textbf{#1.}\hfill{\scriptsize\scshape #2}\quad{\small Ans.}\ \ansblank\par\vspace{1pt}
  \begin{list}{}{\leftmargin=1.6em\rightmargin=0pt\topsep=0pt\parsep=3pt\itemsep=0pt}\item[]}{%
  \end{list}}
\newcommand{\stem}[1]{\par{\itshape #1}\par}
\newcolumntype{L}{>{\raggedright\arraybackslash}X}
\newcommand{\choicesgrid}[4]{%
  \par\vspace{1pt}\begin{tabular}{@{}l@{\ \ }p{0.4\linewidth}@{\quad}l@{\ \ }p{0.4\linewidth}@{}}
  A) & #1 & B) & #2\\ C) & #3 & D) & #4
  \end{tabular}\par}
\newcommand{\choices}[4]{%
  \par\vspace{1pt}\begin{tabular}{@{}l@{\ \ }p{0.85\linewidth}@{}}
  A) & #1\\ B) & #2\\ C) & #3\\ D) & #4
  \end{tabular}\par}

% ---- lexicon entries ------------------------------------------------
\newcommand{\entry}[4]{%
  \par\interlinepenalty=10000\hangindent=1.2em\hangafter=1\noindent
  \textbf{#1}\ {\itshape\small #2}\ #3\ifx&#4&\else\ {\small\textsc{syn.}\ \textit{#4}}\fi\par}

% ---- answer key -----------------------------------------------------
\newcommand{\keystrip}[1]{%
  \begin{center}\small\renewcommand{\arraystretch}{1.25}#1\end{center}}
