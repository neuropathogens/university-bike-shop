#!/usr/bin/env python3
"""Build the SAT Vocabulary study-guide series.

content/defs_*.txt   word|pos|definition[|synonyms]   (## lesson headers in top/mid files)
content/sets_*.txt   practice items (=== set header, @ tag, ? stem, * correct, - wrong, > why)
content/part0_body.tex  hand-written method guide; %%QUESTIONS%% is replaced by the diagnostic
Outputs PDFs into out/.
"""
import glob, json, os, random, re, subprocess, sys
from pypdf import PdfWriter, PdfReader

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, 'out'); BUILD = os.path.join(ROOT, 'build')
os.makedirs(OUT, exist_ok=True); os.makedirs(BUILD, exist_ok=True)

AUTHOR = 'Paul Wang'
COURSE = r'SAT Reading \& Writing \textperiodcentered\ Vocabulary'
DATE = r'November 17, 2026 \textperiodcentered\ Published draft'
LETTERS = 'ABCD'
TAGS = {
    'C': ('WIC-C', 'Words in Context: completion'),
    'M': ('WIC-M', 'Words in Context: meaning as used'),
    'T': ('WIC-T', 'Words in Context: tone and connotation'),
    'X': ('TRN', 'Transitions'),
    'D': ('DEF', 'Definition self-check'),
}
DEFAULT_STEM = {
    'C': 'Which choice completes the text with the most logical and precise word or phrase?',
    'T': 'Which choice completes the text with the most logical and precise word or phrase?',
    'X': 'Which choice completes the text with the most logical transition?',
}

# ------------------------------------------------------------------ text
def tex(s):
    s = s.replace('\\', r'\textbackslash{}')
    for a, b in [('&', r'\&'), ('%', r'\%'), ('$', r'\$'), ('#', r'\#'), ('_', r'\_'),
                 ('{', r'\{'), ('}', r'\}'), ('~', r'\textasciitilde{}'), ('^', r'\textasciicircum{}')]:
        s = s.replace(a, b)
    s = s.replace(r'\_\_\_\_\_\_', '@@BLANK@@').replace(r'\_', r'\_')
    s = re.sub(r'(@@BLANK@@)+', r'\\blank{}', s)
    s = s.replace('−', '$-$').replace('°', r'\textdegree{}').replace('×', r'$\times$')
    # straight double quotes -> TeX quotes
    s = re.sub(r'(^|[\s(\[—–/])"', r'\1``', s)
    s = s.replace('"', "''")
    return s

# ------------------------------------------------------------------ data
def load_defs():
    lessons = {}  # file-group -> list of (lesson, [entries])
    allw = {}
    for f in sorted(glob.glob(os.path.join(ROOT, 'content', 'defs_*.txt'))):
        key = os.path.basename(f)[5:-4]
        cur = None; groups = []
        for line in open(f, encoding='utf8'):
            line = line.rstrip('\n')
            if not line: continue
            if line.startswith('## '):
                cur = (line[3:].strip(), []); groups.append(cur); continue
            p = line.split('|')
            e = dict(word=p[0], pos=p[1], d=p[2], syn=p[3] if len(p) > 3 else '')
            if cur is None:
                cur = ('', []); groups.append(cur)
            cur[1].append(e); allw[p[0].lower()] = e
        lessons[key] = groups
    return lessons, allw

def load_sets():
    sets = []
    for f in sorted(glob.glob(os.path.join(ROOT, 'content', 'sets_*.txt'))):
        cur = None; q = None
        for raw in open(f, encoding='utf8'):
            line = raw.rstrip('\n')
            if line.startswith('=== '):
                n, title, abstract = line[4:].split('|')
                cur = dict(n=int(n), title=title, abstract=abstract, items=[]); sets.append(cur); continue
            if line.startswith('@ '):
                q = dict(tag=line[2:].strip(), text=[], stem=None, right=None, wrong=[], why=''); cur['items'].append(q); continue
            if q is None: continue
            if line.startswith('? '): q['stem'] = line[2:]
            elif line.startswith('* '): q['right'] = line[2:]
            elif line.startswith('- '): q['wrong'].append(line[2:])
            elif line.startswith('> '): q['why'] = line[2:]
            elif line.strip(): q['text'].append(line)
    for s in sets:
        for i, q in enumerate(s['items'], 1):
            assert q['right'] and len(q['wrong']) == 3 and q['why'], (s['n'], i, q['text'][:1])
            assert len({q['right'], *q['wrong']}) == 4, (s['n'], i)
            if q['tag'] in 'CTX': assert '______' in ' '.join(q['text']), (s['n'], i)
    return sorted(sets, key=lambda s: s['n'])

def assign_positions(items, seed):
    """Balanced answer letters (as even as possible), no letter more than twice in a row."""
    rng = random.Random(seed)
    n = len(items)
    for _ in range(10000):
        pos = [i % 4 for i in range(n)]; rng.shuffle(pos)
        if all(not (pos[i] == pos[i-1] == pos[i-2]) for i in range(2, n)): break
    for q, p in zip(items, pos):
        opts = q['wrong'][:]; rng.shuffle(opts); opts.insert(p, q['right'])
        q['opts'] = opts; q['ans'] = LETTERS[p]

# ------------------------------------------------------------------ rendering
def preamble(partlabel, title, abstract, keywords, scoring=''):
    return (r'\documentclass{satvocab}' '\n'
            rf'\title{{{title}}}\author{{{AUTHOR}}}\date{{{DATE}}}' '\n'
            rf'\partlabel{{{partlabel}}}\course{{{COURSE}}}\keywords{{{keywords}}}\scoring{{{scoring}}}' '\n'
            r'\begin{document}\maketitle' '\n'
            rf'\begin{{abstract}}{abstract}\end{{abstract}}' '\n')

def render_question(num, q):
    tag = TAGS[q['tag']][0]
    out = [rf'\begin{{question}}{{{num}}}{{{tag}}}']
    out.append(tex(' '.join(q['text'])))
    out.append(rf'\stem{{{tex(q["stem"] or DEFAULT_STEM[q["tag"]])}}}')
    cmd = r'\choicesgrid' if max(len(o) for o in q['opts']) <= 30 else r'\choices'
    out.append(cmd + ''.join('{%s}' % tex(o) for o in q['opts']))
    out.append(r'\end{question}')
    return '\n'.join(out)

def render_key(items, extra=''):
    n = len(items)
    cols = 10 if n >= 10 else n
    rows = []
    for r in range(0, n, cols):
        chunk = items[r:r+cols]
        rows.append(' & '.join(rf'\textbf{{{r+i+1}}}\,{q["ans"]}' for i, q in enumerate(chunk)) +
                    ' & ' * (cols - len(chunk)) + r'\\')
    strip = r'\begin{tabular}{' + '|'.join(['c'] * cols) + r'}\toprule ' + r' \midrule '.join(rows) + r'\bottomrule\end{tabular}'
    out = [r'\clearpage\section*{Answer key}\addcontentsline{toc}{section}{Answer key}',
           r'\textbf{Answers only}', rf'\keystrip{{{strip}}}']
    if extra: out.append(extra)
    out.append(r'\par\textbf{Explanations}')
    out.append(r'{\footnotesize\setlength{\tabcolsep}{4pt}\begin{longtable}{@{}r c p{0.74\textwidth} l@{}}' '\n'
               r'\toprule \# & Ans. & Why & Rule\\ \midrule\endfirsthead' '\n'
               r'\toprule \# & Ans. & Why & Rule\\ \midrule\endhead')
    for i, q in enumerate(items, 1):
        why = tex(q['why']) if not q.get('why_tex') else q['why_tex']
        out.append(rf'{i} & {q["ans"]} & {why} & {TAGS[q["tag"]][0]}\\')
    out.append(r'\bottomrule\end{longtable}}')
    return '\n'.join(out)

def rule_breakdown(items):
    counts = {}
    for q in items: counts[q['tag']] = counts.get(q['tag'], 0) + 1
    cells = [rf'{TAGS[t][0]} \rule{{1.6em}}{{0.4pt}}\,/\,{c}' for t, c in counts.items()]
    return r'\par\noindent\textbf{Score by rule:}\ ' + r'\quad '.join(cells) + r'\par'

def write_compile(name, body):
    texpath = os.path.join(BUILD, name + '.tex')
    open(texpath, 'w', encoding='utf8').write(body + '\n\\end{document}\n')
    env = dict(os.environ, TEXINPUTS=os.path.join(ROOT, 'tex') + '//:')
    for _ in range(2):
        r = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', name + '.tex'],
                           cwd=BUILD, env=env, capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stdout[-3000:]); sys.exit(f'LaTeX failed: {name}')
    os.replace(os.path.join(BUILD, name + '.pdf'), os.path.join(OUT, name + '.pdf'))
    return os.path.join(OUT, name + '.pdf')

# ------------------------------------------------------------------ self-check items (auto)
def defcheck(entries, n, seed, ref):
    rng = random.Random(seed)
    pick = rng.sample(entries, n); items = []
    for e in pick:
        same = [x for x in entries if x is not e and x['pos'].split('/')[0] == e['pos'].split('/')[0]
                and x['d'] != e['d']]
        if len(same) < 3: same = [x for x in entries if x is not e and x['d'] != e['d']]
        wrong = [x['d'] for x in rng.sample(same, 3)]
        items.append(dict(tag='D', text=[f'Which choice best defines “{e["word"]}” ({e["pos"]})?'],
                          stem=None, right=e['d'], wrong=wrong,
                          why=f'{e["word"]} ({e["pos"]}): {e["d"]}. See {ref(e)}.'))
    return items

def render_defcheck_q(num, q):
    out = [rf'\begin{{question}}{{{num}}}{{DEF}}', tex(q['text'][0]).replace('“', '``').replace('”', "''")]
    out.append(r'\choices' + ''.join('{%s}' % tex(o) for o in q['opts']))
    out.append(r'\end{question}')
    return '\n'.join(out)

# ------------------------------------------------------------------ parts
def build_part0(sets):
    diag = sets[0]; assert diag['n'] == 0
    assign_positions(diag['items'], 1000)
    qs = '\n'.join(render_question(i, q) for i, q in enumerate(diag['items'], 1))
    body = open(os.path.join(ROOT, 'content', 'part0_body.tex'), encoding='utf8').read().replace('%%QUESTIONS%%', qs)
    abstract = ('This paper introduces a ten-set, four-part study series for the vocabulary tested on the digital SAT. '
                'It covers every word in the Sesame Words SAT lists (450 top-, 1,350 mid- and 2,700 low-frequency entries; 3,660 unique words after duplicates are removed). '
                'This part explains how vocabulary is tested (Words in Context completion, meaning-in-context, tone and transitions), gives a six-step method and a taxonomy of eight trap types, '
                'and supplies reference tables of secondary meanings, roots, prefixes, suffixes and transitions. It closes with an eight-week plan and an eight-item diagnostic.')
    pre = preamble('Part 0', 'SAT Vocabulary, Part 0: How the Test Works, Method and Word Roots', abstract,
                   'digital SAT; Words in Context; Craft and Structure; transitions; connotation; etymology',
                   r'Diagnostic \rule{1.6em}{0.4pt}\,/\,8 \textperiodcentered\ target time 10 min')
    return write_compile('00-SAT-Vocab-Overview-and-Method', pre + body + '\n' + render_key(diag['items']))

LEX_MAP_TOP = [('1.1', '1.5', 1), ('1.6', '1.10', 2), ('1.11', '1.15', 3)]
LEX_MAP_MID = [('2.1', '2.15', 4), ('2.16', '2.30', 5), ('2.31', '2.45', 6)]

def lesson_num(l): a, b = l.split('.'); return (int(a), int(b))

def build_lexicon_lessons(name, partlabel, title, abstract, keywords, groups, ranges, intro, seed, show_syn):
    entries = [e for _, es in groups for e in es]
    lesson_of = {e['word']: l for l, es in groups for e in es}
    body = [r'\section{How to use this lexicon}', intro,
            r'\begin{table}[h]\centering\caption{Lesson groups and the practice set that tests them.}'
            r'\begin{tabular}{@{}lrl@{}}\toprule Lessons & Words & Practice set\\\midrule']
    for a, b, s in ranges:
        cnt = sum(len(es) for l, es in groups if lesson_num(a) <= lesson_num(l) <= lesson_num(b))
        body.append(rf'{a}--{b} & {cnt} & Set {s}\\')
    body.append(rf'\midrule Total & {len(entries)} & \\\bottomrule\end{{tabular}}\end{{table}}')
    for a, b, s in ranges:
        body.append(rf'\section{{Lessons {a}--{b}}}')
        body.append(rf'Tested in Practice Set {s}.')
        for l, es in groups:
            if not (lesson_num(a) <= lesson_num(l) <= lesson_num(b)): continue
            body.append(rf'\subsection{{Lesson {l}}}\begin{{multicols}}{{2}}\small')
            for e in es:
                body.append(rf'\entry{{{tex(e["word"])}}}{{{tex(e["pos"])}}}{{{tex(e["d"])}}}{{{tex(e["syn"]) if show_syn else ""}}}')
            body.append(r'\end{multicols}')
    items = defcheck(entries, 20, seed, lambda e: f'Lesson {lesson_of[e["word"]]}')
    assign_positions(items, seed + 1)
    body.append(r'\section{Self-check}Twenty words drawn at random from this part. Choose the definition; answers follow on the last page.')
    body += [render_defcheck_q(i, q) for i, q in enumerate(items, 1)]
    body.append(render_key(items))
    pre = preamble(partlabel, title, abstract, keywords, r'Self-check \rule{1.6em}{0.4pt}\,/\,20')
    return write_compile(name, pre + '\n'.join(body))

def build_part1(lex):
    groups = lex['top']
    intro = (r'Each entry gives the headword in bold, its part of speech in italics, a definition written for SAT contexts, and two synonyms (\textsc{syn.}). '
             r'Where a word has a second meaning the SAT tests, both are given, separated by a semicolon; the synonyms follow the same order. '
             r'Lessons follow the Sesame Words ordering of 30 words each (Lesson~1.5 has 29 because the source lists \emph{defy} twice). '
             r'Abbreviations: \textit{n.}\ noun, \textit{v.}\ verb, \textit{adj.}\ adjective, \textit{adv.}\ adverb.')
    abstract = ('The 449 highest-frequency SAT words, in the fifteen Sesame Words lessons (1.1--1.15). Every entry has a part of speech, an SAT-focused definition that flags tested secondary meanings, and two synonyms. '
                'These words appear most often in College Board passages and answer choices, so learn them first. A 20-item self-check closes the part.')
    return build_lexicon_lessons('01-SAT-Vocab-Lexicon-I-Top-Frequency', 'Part 1', 'SAT Vocabulary, Part 1: Lexicon I, Top-Frequency Words (450)',
                                 abstract, 'top-frequency; Lessons 1.1--1.15; definitions; synonyms', groups, LEX_MAP_TOP, intro, 11, True)

def build_part2(lex):
    groups = lex['mid1'] + lex['mid2']
    intro = (r'Each entry gives the headword in bold, its part of speech in italics, and a short SAT-focused definition. '
             r'Multiple senses are separated by semicolons, and the SAT-relevant sense is listed where it matters. '
             r'Transition words on this list (\emph{furthermore}, \emph{nevertheless}, \emph{hence}, \emph{likewise}, \emph{nonetheless}) are glossed by the logical relationship they signal. '
             r'Lessons follow the Sesame Words ordering of 30 words each (Lesson~2.45 has 29 in the source).')
    abstract = ('The 1,349 mid-frequency SAT words in the forty-five Sesame Words lessons (2.1--2.45), each with part of speech and a concise SAT-focused definition. '
                'These are the academic workhorse words of science, history and social-science passages. A 20-item self-check closes the part.')
    return build_lexicon_lessons('02-SAT-Vocab-Lexicon-II-Mid-Frequency', 'Part 2', 'SAT Vocabulary, Part 2: Lexicon II, Mid-Frequency Words (1,350)',
                                 abstract, 'mid-frequency; Lessons 2.1--2.45; academic vocabulary', groups, LEX_MAP_MID, intro, 22, False)

def build_part3(lex):
    lists = json.load(open(os.path.join(ROOT, 'lists.json')))
    low = [e for g in ('low1', 'low2', 'low3', 'low4') for _, es in lex[g] for e in es]
    low.sort(key=lambda e: e['word'].lower())
    where = {}
    for l, ws in lists['top'] + lists['mid']:
        for w in ws: where[w.lower()] = l
    ranges = [('A', 'C', 7), ('D', 'F', 7), ('G', 'L', 8), ('M', 'P', 8), ('Q', 'S', 9), ('T', 'Z', 9)]
    body = [r'\section{How to use this lexicon}',
            (r'The Sesame Words low-frequency list (2,700 entries) is unsorted and overlaps heavily with the two higher lists. '
             r'This part defines the 1,862 words that appear \emph{only} on the low list, alphabetically. '
             rf'The other {len(lists["lowdup"])} low-list words are already defined in Parts~1--2; Section~\ref{{sec:xref}} lists them with their lesson numbers, so every word on the source list is covered once. '
             r'These words rarely appear as correct answers, but they show up often as distractors and in harder passages, which is where students aiming above 700 pick up points.'),
            r'\begin{table}[h]\centering\caption{Letter groups and the practice set that tests them.}\begin{tabular}{@{}lrl@{}}\toprule Letters & Words & Practice set\\\midrule']
    for a, b, s in ranges:
        cnt = sum(1 for e in low if a <= e['word'][0].upper() <= b)
        body.append(rf'{a}--{b} & {cnt} & Set {s}\\')
    body.append(rf'\midrule Total & {len(low)} & \\\bottomrule\end{{tabular}}\end{{table}}')
    for a, b, s in ranges:
        body.append(rf'\section{{Words {a}--{b}}}Tested in Practice Set {s}.')
        for L in [chr(c) for c in range(ord(a), ord(b) + 1)]:
            es = [e for e in low if e['word'][0].upper() == L]
            if not es: continue
            body.append(rf'\subsection{{{L}}}\begin{{multicols}}{{2}}\small')
            body += [rf'\entry{{{tex(e["word"])}}}{{{tex(e["pos"])}}}{{{tex(e["d"])}}}{{}}' for e in es]
            body.append(r'\end{multicols}')
    body.append(r'\section{Low-list words defined in Parts 1--2}\label{sec:xref}')
    body.append(r'Each word below is on the low-frequency list and also on a higher list; the number is the lesson where it is defined (1.x = Part~1, 2.x = Part~2).')
    body.append(r'\begin{multicols}{4}\footnotesize\raggedright')
    body += [rf'{tex(w)}\ \textit{{{where[w]}}}\\' for w in sorted(lists['lowdup'])]
    body.append(r'\end{multicols}')
    items = defcheck(low, 20, 33, lambda e: f'Part 3, {e["word"][0].upper()}')
    assign_positions(items, 34)
    body.append(r'\section{Self-check}Twenty words drawn at random from this part. Choose the definition; answers follow on the last page.')
    body += [render_defcheck_q(i, q) for i, q in enumerate(items, 1)]
    body.append(render_key(items))
    abstract = ('The 1,862 words found only on the Sesame Words low-frequency list, A--Z, each with part of speech and a concise definition. '
                f'A cross-reference covers the remaining {len(lists["lowdup"])} low-list words that are defined in Parts 1--2, so the full list is covered. '
                'These words are the long tail for students targeting 700+. A 20-item self-check closes the part.')
    pre = preamble('Part 3', 'SAT Vocabulary, Part 3: Lexicon III, Low-Frequency Words (2,700)', abstract,
                   'low-frequency; advanced vocabulary; distractors; cross-reference', r'Self-check \rule{1.6em}{0.4pt}\,/\,20')
    return write_compile('03-SAT-Vocab-Lexicon-III-Low-Frequency', pre + '\n'.join(body))

SET_SOURCES = {1: 'Lessons 1.1--1.5', 2: 'Lessons 1.6--1.10', 3: 'Lessons 1.11--1.15', 4: 'Lessons 2.1--2.15',
               5: 'Lessons 2.16--2.30', 6: 'Lessons 2.31--2.45', 7: 'Part 3, A--F', 8: 'Part 3, G--P',
               9: 'Part 3, Q--Z, plus phrases', 10: 'all parts'}

def build_set(s):
    items = s['items']; assign_positions(items, 500 + s['n'])
    body = [r'\section{Directions}',
            (r'Twenty single-passage questions, four choices each, in the digital SAT format. '
             r'Allow 24 minutes, which is the Reading and Writing pace of about 71 seconds per question. '
             r'Write your letter in the blank beside each number. Use the six-step method from Part~0: cover the choices, find the clue, predict, fix the charge, eliminate by trap type, and reread. '
             rf'Words are drawn mainly from {SET_SOURCES[s["n"]]}; correct answers and distractors both count as study material.')]
    num = 1
    for t in 'CMTX':
        group = [q for q in items if q['tag'] == t]
        if not group: continue
        body.append(rf'\section{{{TAGS[t][1]} ({TAGS[t][0]})}}')
        for q in group:
            body.append(render_question(num, q)); num += 1
    ordered = [q for t in 'CMTX' for q in items if q['tag'] == t]
    body.append(render_key(ordered, rule_breakdown(ordered)))
    abstract = (f'Practice Set {s["n"]} of 10. {s["abstract"]} The set has twenty original items: '
                f'{sum(q["tag"]=="C" for q in items)} completions, {sum(q["tag"]=="M" for q in items)} meaning-in-context, '
                f'{sum(q["tag"]=="T" for q in items)} tone/connotation and {sum(q["tag"]=="X" for q in items)} transitions. Answer letters are balanced across A--D, and the key gives the reason and rule for every item.')
    pre = preamble(f'Practice Set {s["n"]}', f'SAT Vocabulary, Practice Set {s["n"]}: {s["title"]}', tex(abstract).replace('A--D', 'A--D'),
                   'Words in Context; transitions; connotation; ' + SET_SOURCES[s['n']],
                   r'\rule{1.6em}{0.4pt}\,/\,20 \textperiodcentered\ 24 minutes \textperiodcentered\ 18+ = mastery, 15--17 = review misses, $\le$14 = relearn the lessons')
    return write_compile(f'{3 + s["n"]:02d}-SAT-Vocab-Practice-Set-{s["n"]:02d}', pre + '\n'.join(body))

def main():
    lex, allw = load_defs()
    sets = load_sets()
    pdfs = [build_part0(sets), build_part1(lex), build_part2(lex), build_part3(lex)]
    for s in sets[1:]:
        pdfs.append(build_set(s))
    w = PdfWriter()
    names = ['Part 0: Overview, Method and Roots', 'Part 1: Lexicon I (Top)', 'Part 2: Lexicon II (Mid)', 'Part 3: Lexicon III (Low)'] + \
            [f'Practice Set {i}' for i in range(1, 11)]
    for p, nm in zip(pdfs, names):
        w.append(p, outline_item=nm)
    w.add_metadata({'/Title': 'SAT Vocabulary Series (Complete)', '/Author': AUTHOR})
    final = os.path.join(OUT, 'SAT-Vocab-Complete-Series.pdf'); w.write(final)
    for p in pdfs + [final]:
        print(f'{os.path.basename(p):55s} {len(PdfReader(p).pages):4d} pp')
    # answer balance report
    for s in sets:
        c = {L: 0 for L in LETTERS}
        for q in s['items']: c[q['ans']] += 1
        print('set', s['n'], c)

if __name__ == '__main__':
    main()
