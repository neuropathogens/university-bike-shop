"""Render the 10 SAT Conventions practice sets to LaTeX and compile them.

usage: python3 build.py            -> writes tex/N-*.tex, compiles to out/
"""
import random
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "content"))
from model import RULES, SECTIONS  # noqa: E402
from sets_a import SET1, SET2, SET3, SET4, SET5  # noqa: E402
from sets_b import SET6, SET7, SET8, SET9, SET10  # noqa: E402

SETS = [SET1, SET2, SET3, SET4, SET5, SET6, SET7, SET8, SET9, SET10]
LETTERS = "ABCD"
DATE = "November 17, 2026"
COURSE = r"SAT Reading and Writing --- Standard English Conventions"


def arrange(n, items):
    """Return list of (item, choices, answer_index) with balanced A-D answers."""
    rng = random.Random(1000 + n)
    order = list(range(20))
    if n >= 9:  # simulation sets: test order, no grouping
        rng.shuffle(order)
    positions = [0, 1, 2, 3] * 5
    while True:  # no letter more than twice in a row
        rng.shuffle(positions)
        if all(not (positions[i] == positions[i + 1] == positions[i + 2]) for i in range(18)):
            break
    out = []
    for k, idx in enumerate(order):
        q = items[idx]
        choices = list(q.wrong)
        choices.insert(positions[k], q.correct)
        out.append((idx, q, choices, positions[k]))
    return out


def item_tex(num, q, choices):
    stem = q.stem.replace("___", r"\blank{}")
    ch = "\n".join(rf"  \item {c}" for c in choices)
    return rf"""\noindent\begin{{minipage}}{{\linewidth}}
\textbf{{{num}.}}\hfill\ansline\par\vspace{{1pt}}
{stem}
\begin{{choices}}
{ch}
\end{{choices}}
\end{{minipage}}\par\medskip
"""


def set_tex(n, items):
    arranged = arrange(n, items)
    sim = n >= 9
    rules = Counter(q.rule for q in items)
    body = []
    if sim:
        body.append(r"\section{Simulation: items in test order}" "\n"
                    r"\emph{The 20 items below mix every rule family without headings, as on the test. Work them in one sitting.}\par\medskip" "\n")
        for k, (_, q, ch, _) in enumerate(arranged, 1):
            body.append(item_tex(k, q, ch))
    else:
        for title, a, b, guide in SECTIONS:
            body.append(rf"\section{{{title}}}" "\n"
                        rf"\emph{{Items {a}--{b}. Rules in guide {guide}.}}\par\medskip" "\n")
            for k in range(a, b + 1):
                _, q, ch, _ = arranged[k - 1]
                body.append(item_tex(k, q, ch))

    # answer key
    strip_rows = []
    for half in (range(1, 11), range(11, 21)):
        nums = " & ".join(str(k) for k in half)
        ans = " & ".join(rf"\textbf{{{LETTERS[arranged[k-1][3]]}}}" for k in half)
        strip_rows.append(rf"\# & {nums} \\ Ans. & {ans} \\")
    strip = (r"\begin{tabular}{@{}l*{10}{c}@{}}\toprule" "\n"
             + strip_rows[0] + r"\midrule" "\n" + strip_rows[1] + r"\bottomrule\end{tabular}")
    key_rows = []
    for k, (_, q, _, pos) in enumerate(arranged, 1):
        key_rows.append(rf"{k} & {LETTERS[pos]} & {q.why} & \S{q.rule} {RULES[q.rule]} \\")
    key = "\n".join(key_rows)

    mode = ("Items appear in test order with no section headings; treat it as a timed simulation."
            if sim else
            "Items are grouped into five numbered sections by rule family so that misses can be traced to one family.")
    tag_list = ", ".join(rf"\S{r}" for r in sorted(rules, key=lambda s: [int(x) for x in s.split('.')]))

    return rf"""\documentclass[11pt]{{article}}
\input{{preamble}}
\title{{\textbf{{Standard English Conventions on the Digital SAT:\\ Practice Set {n}}}}}
\author{{Paul Wang\\[2pt]
  \small Course: {COURSE}\\
  \small Part {n} of 11 \quad$\cdot$\quad 20 items \quad$\cdot$\quad Companion to Part 0 (the guide)}}
\date{{{DATE}}}
\begin{{document}}
\maketitle
\thispagestyle{{fancy}}
\begin{{abstract}}
\noindent This set contains 20 original items in the Digital SAT format: a short text with one blank and four choices. Ten items test Boundaries (how clauses and phrases are joined and punctuated) and ten test Form, Structure, and Sense (agreement, tense, verb form, possessives, pronouns, and modifier placement), matching the domain's roughly even split on the test. {mode} The answer key on the last page gives each answer, a one-line reason, and the guide section that states the rule. Rules tested: {tag_list}.
\keywords{{SAT, Standard English Conventions, Boundaries, Form Structure and Sense, practice set {n}}}
\end{{abstract}}

\scoreline

\paragraph{{Directions.}} For every item, answer the same question: \stem{{}} Write the letter in the blank beside the item number. Allow 24 minutes.

{''.join(body)}

\clearpage
\section*{{Answer key: Set {n}}}
\noindent\textbf{{Answers only.}}\par\smallskip
\noindent{strip}

\medskip
\noindent\textbf{{Explanations.}} The Rule column gives the section of Part 0 that states the rule.\par
\footnotesize
\setlength{{\LTpre}}{{4pt}}\setlength{{\LTpost}}{{0pt}}
\renewcommand{{\arraystretch}}{{1.08}}
\begin{{longtable}}{{@{{}}r c >{{\raggedright\arraybackslash}}p{{10.6cm}} >{{\raggedright\arraybackslash}}p{{3.1cm}}@{{}}}}
\toprule
\# & Ans. & Why & Rule \\
\midrule
\endhead
{key}
\bottomrule
\end{{longtable}}
\end{{document}}
"""


def main():
    tex = ROOT / "tex"
    build = ROOT / "build"
    out = ROOT / "out"
    out.mkdir(exist_ok=True)
    names = []
    for n, items in enumerate(SETS, 1):
        assert len(items) == 20, (n, len(items))
        name = f"{n}-SAT-Conventions-Practice-Set-{n:02d}" if n < 10 else "10-SAT-Conventions-Practice-Set-10"
        (tex / f"{name}.tex").write_text(set_tex(n, items))
        names.append(name)
    names.insert(0, "0-SAT-Conventions-Guide")
    env = {"TEXINPUTS": str(tex) + "//:", "PATH": "/usr/bin:/bin:/usr/local/bin"}
    for name in names:
        for _ in range(2):
            r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                                str(tex / f"{name}.tex")], cwd=build, env=env,
                               capture_output=True, text=True)
        if r.returncode:
            print(r.stdout[-2500:])
            raise SystemExit(f"FAILED {name}")
        log = (build / f"{name}.log").read_text(errors="ignore")
        over = [l for l in log.splitlines() if l.startswith("Overfull")]
        pages = [l for l in log.splitlines() if "Output written" in l]
        print(name, pages[-1].split("(")[1].split(",")[0] if pages else "?", f"overfull={len(over)}")
        (out / f"{name}.pdf").write_bytes((build / f"{name}.pdf").read_bytes())
    subprocess.run(["pdfunite", *[str(out / f"{n}.pdf") for n in names],
                    str(out / "SAT-Conventions-Complete-Series.pdf")], check=True)


if __name__ == "__main__":
    main()
