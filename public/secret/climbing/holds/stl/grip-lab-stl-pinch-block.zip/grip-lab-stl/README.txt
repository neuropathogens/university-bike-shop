grip-lab: print files
=====================

Every file sits on the bed (Z = 0) in its print orientation: do not rotate it. Units: mm.
Settings: 0.4 mm nozzle, 0.2 mm layers, 6 perimeters, 4 mm solid top/bottom, 40 % gyroid, no supports.
Load pieces: PA6-CF or PA12-CF preferred, PETG minimum. Never PLA for anything you hang from.
Proof-test every load piece at 1.5x its rating for 30 s before use.
Untested design: print and load at your own risk. Full notes: https://universitybikeshop.com/secret/climbing/holds/stl/


MODULAR EDGE BLOCK
------------------
One spine and any of the six reversible cassettes. Each cassette gives two edge depths: flip it end for end. Two cassettes fit the spine at once (one per face). Print the depths you train on.
   1 x  Spine                                        PA-CF, PETG min.   edge_block/spine.stl
   1 x  Cassette, 6 / 8 mm                           PA-CF, PETG min.   edge_block/cassette_06_08.stl
   1 x  Cassette, 10 / 12 mm                         PA-CF, PETG min.   edge_block/cassette_10_12.stl
   1 x  Cassette, 14 / 15 mm                         PA-CF, PETG min.   edge_block/cassette_14_15.stl
   1 x  Cassette, 18 / 20 mm                         PA-CF, PETG min.   edge_block/cassette_18_20.stl
   1 x  Cassette, 20 mm R10 / 20 mm 3° incut         PA-CF, PETG min.   edge_block/cassette_20r10_20i3.stl
   1 x  Cassette, 22 / 25 mm                         PA-CF, PETG min.   edge_block/cassette_22_25.stl

LOAD-CELL GAUGE HOUSING
-----------------------
The housing carries no load. Its pocket is drawn for a nominal 200 kg M12 S-beam cell: measure your cell first.
   1 x  Front shell                                  PETG               load_cell_gauge/front_shell.stl
   1 x  Back shell                                   PETG               load_cell_gauge/back_shell.stl
   1 x  Electronics sled with end cap                PETG               load_cell_gauge/sled.stl
   1 x  End-cap gasket                               TPU 95A            load_cell_gauge/gasket.stl

ADJUSTABLE PINCH BLOCK
----------------------
One hub, two jaws of the same face, four sets of width sleeves and four end caps. Choose one jaw face and print two of it. The jaws are large files because the stipple is modelled.
   1 x  Hub                                          PA-CF, PETG min.   pinch_block/hub.stl
   2 x  Jaw, flat face                               PA-CF, PETG min.   pinch_block/jaw_flat.stl
   2 x  Jaw, 5° taper                                PA-CF, PETG min.   pinch_block/jaw_taper5.stl
   2 x  Jaw, round (R8 top edges)                    PA-CF, PETG min.   pinch_block/jaw_round.stl
   4 x  Width sleeve, 2.5 mm                         PETG or better     pinch_block/sleeve_2p5.stl
   4 x  Width sleeve, 5 mm                           PETG or better     pinch_block/sleeve_5.stl
   4 x  Width sleeve, 10 mm                          PETG or better     pinch_block/sleeve_10.stl
   4 x  Width sleeve, 20 mm                          PETG or better     pinch_block/sleeve_20.stl
   4 x  Rod end cap                                  PETG or better     pinch_block/cap.stl

SLOPER DIAL
-----------
Print files.
   1 x  Disc (15, 25, 35, 45° facets)                PA-CF, PETG min.   sloper_dial/disc.stl

WARM-UP EDGE PUCK
-----------------
Print files.
   1 x  Puck (25, 20, 15 mm lips + pinch)            PETG or better     warmup_puck/puck.stl

EXTENSOR TRAINER
----------------
Print files.
   1 x  Hub                                          PETG               extensor_trainer/hub.stl
   4 x  Finger cup                                   TPU 95A            extensor_trainer/cup_finger.stl
   1 x  Thumb cup                                    TPU 95A            extensor_trainer/cup_thumb.stl

POCKET BLOCK
------------
Uses the edge-block spine (the same file). Rated 60 kg: never shock-load a two-finger pocket.
   1 x  Spine (same as the edge block)               PA-CF, PETG min.   edge_block/spine.stl
   1 x  Pocket cassette, 2F15 / 2F20                 PA-CF, PETG min.   pocket_block/pocket_2f15_2f20.stl
   1 x  Pocket cassette, 2F25 / 3F15                 PA-CF, PETG min.   pocket_block/pocket_2f25_3f15.stl
   1 x  Pocket cassette, 3F20 / 3F25                 PA-CF, PETG min.   pocket_block/pocket_3f20_3f25.stl

FINGER ISOLATION TRAINER
------------------------
Drawn for the default finger widths in params.toml; rebuild them for your own hand before printing.
   1 x  Cradle, index                                PA-CF, PETG min.   finger_isolation/cradle_index.stl
   1 x  Cradle, middle                               PA-CF, PETG min.   finger_isolation/cradle_middle.stl
   1 x  Cradle, ring                                 PA-CF, PETG min.   finger_isolation/cradle_ring.stl
   1 x  Cradle, little                               PA-CF, PETG min.   finger_isolation/cradle_pinky.stl

HEX DUMBBELL PINCH CLAMP
------------------------
Pick the collar that matches your dumbbell handle and print both halves.
   1 x  Collar 70 mm, front half                     PETG or better     dumbbell_clamp/front_70.stl
   1 x  Collar 70 mm, back half                      PETG or better     dumbbell_clamp/back_70.stl
   1 x  Collar 90 mm, front half                     PETG or better     dumbbell_clamp/front_90.stl
   1 x  Collar 90 mm, back half                      PETG or better     dumbbell_clamp/back_90.stl

THICK-GRIP WRIST ROLLER
-----------------------
One spool, one pawl, and one fixed + one free sleeve in the grip diameter you want.
   1 x  Ratchet spool                                PETG or better     wrist_roller/spool.stl
   1 x  Pawl                                         PA6-CF / PA12-CF   wrist_roller/pawl.stl
   1 x  Sleeve 40 mm, fixed                          PETG               wrist_roller/fixed_40.stl
   1 x  Sleeve 40 mm, free                           PETG               wrist_roller/free_40.stl
   1 x  Sleeve 50 mm, fixed                          PETG               wrist_roller/fixed_50.stl
   1 x  Sleeve 50 mm, free                           PETG               wrist_roller/free_50.stl
   1 x  Sleeve 60 mm, fixed                          PETG               wrist_roller/fixed_60.stl
   1 x  Sleeve 60 mm, free                           PETG               wrist_roller/free_60.stl

TOLERANCE COUPONS (OPTIONAL)
----------------------------
Tolerance coupons, one file per coupon set.
        Dovetail: rail + seven keys, 0.10–0.40 mm                       coupons/dovetail.stl
        16 mm rod bore bar                                              coupons/rod_bore.stl
        M10 bolt bore strip + washer seats                              coupons/bolt_bore.stl
        Ball-lock pin detent plate                                      coupons/pin_detent.stl
        Heat-set insert bosses, M3 / M4 / M6                            coupons/insert.stl
        Stipple texture, 0.15 / 0.25 / 0.35 mm                          coupons/texture.stl

Licence: personal use by the buyer. Do not resell, share or redistribute these files or units
printed from them without a written licence. (c) grip-lab. All rights reserved.
